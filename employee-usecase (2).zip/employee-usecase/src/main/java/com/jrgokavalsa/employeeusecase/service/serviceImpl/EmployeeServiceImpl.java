package com.jrgokavalsa.employeeusecase.service.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.jrgokavalsa.employeeusecase.dto.EmployeeDto;
import com.jrgokavalsa.employeeusecase.entity.Employee;
import com.jrgokavalsa.employeeusecase.exceptions.EmployeeNotFoundException;
import com.jrgokavalsa.employeeusecase.repository.EmployeeRepository;
import com.jrgokavalsa.employeeusecase.service.EmployeeService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

	private final EmployeeRepository employeeRepository;

	@Override
	public String addEmployee(EmployeeDto employee) {
		log.info("Entering add Employee in the Employeeservice -");

		Employee empObject = new Employee();
		empObject.setEmployeeName(employee.getEmployeeName());
		empObject.setEmployeeCode(employee.getEmployeeCode());
		empObject.setEmail(employee.getEmail());
		empObject.setExperience(employee.getExperience());
		empObject.setLocation(employee.getLocation());
		empObject.setProjectStatus(employee.getProjectStatus());

		employeeRepository.save(empObject);

		return "added successfully - " + employee.getEmail();
	}

	@Override
	public List<EmployeeDto> getAllEmployees() {
		return employeeRepository.findAll().stream().map(emp -> {
			EmployeeDto dto = new EmployeeDto();
			dto.setEmail(emp.getEmail());
			dto.setEmployeeCode(emp.getEmployeeCode());
			dto.setEmployeeName(emp.getEmployeeName());
			dto.setExperience(emp.getExperience());
			dto.setLocation(emp.getLocation());
			dto.setProjectStatus(emp.getProjectStatus());
			return dto;
		}).toList();
	}

	@Override
	public EmployeeDto getEmployeeById(Long id) {

		return employeeRepository.findById(id).map(emp -> {
			EmployeeDto dto = new EmployeeDto();
			dto.setEmail(emp.getEmail());
			dto.setEmployeeCode(emp.getEmployeeCode());
			dto.setEmployeeName(emp.getEmployeeName());
			dto.setExperience(emp.getExperience());
			dto.setLocation(emp.getLocation());
			dto.setProjectStatus(emp.getProjectStatus());
			return dto;
		}).orElseThrow(()->new EmployeeNotFoundException("Employee Not found with id - "+id));
	}

}
