package com.jrgokavalsa.employeeusecase.dto;

import javax.validation.constraints.Email;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EmployeeDto {
	private Long employeeCode;
	private String employeeName;
	@Email(message="Email is invalid.. Please try with valid email address")
	private String email;
	private Integer experience;
	private String location;
	private String projectStatus;
}
