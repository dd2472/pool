package com.jrgokavalsa.employeeusecase.service;

import java.util.List;

import com.jrgokavalsa.employeeusecase.dto.EmployeeDto;
import com.jrgokavalsa.employeeusecase.entity.Employee;

public interface EmployeeService {
	
	public String addEmployee(EmployeeDto employee) ;

	public List<EmployeeDto> getAllEmployees();

	public EmployeeDto getEmployeeById(Long id);
}
