package com.jrgokavalsa.employeeusecase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
/* @ComponentScan(basePackages = {"com.jrgokavalsa"}) */
public class EmployeeUsecaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeUsecaseApplication.class, args);
	}

}
