package com.jrgokavalsa.employeeusecase.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Id;
	private Long employeeCode;
	private String employeeName;
	private String email;
	private Integer experience;
	private String location;
	private String projectStatus;
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public Long getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(Long employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getExperience() {
		return experience;
	}
	public void setExperience(Integer experience) {
		this.experience = experience;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getProjectStatus() {
		return projectStatus;
	}
	public void setProjectStatus(String projectStatus) {
		this.projectStatus = projectStatus;
	}
	@Override
	public String toString() {
		return "Employee [Id=" + Id + ", employeeCode=" + employeeCode + ", employeeName=" + employeeName + ", email="
				+ email + ", experience=" + experience + ", location=" + location + ", projectStatus=" + projectStatus
				+ "]";
	}
	
	public Employee(Long id, Long employeeCode, String employeeName, String email, Integer experience, String location,
			String projectStatus) {
		super();
		Id = id;
		this.employeeCode = employeeCode;
		this.employeeName = employeeName;
		this.email = email;
		this.experience = experience;
		this.location = location;
		this.projectStatus = projectStatus;
	}
	public Employee() {
	
	}
	
	
}
